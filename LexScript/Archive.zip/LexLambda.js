var AWS = require('aws-sdk');
var async = require("async");
var ddb = new AWS.DynamoDB();


// Close dialog with the customer, reporting fulfillmentState of Failed or Fulfilled ("Thanks, your pizza will arrive in 20 minutes")
function close(sessionAttributes, fulfillmentState, message) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'Close',
            fulfillmentState,
            message,
        },
    };
}

function getAll(sessionAttributes, fulfillmentState, target, callback) {
	var tableName;
	if (target == "devices") {
		tableName = "DevicesTable";
	} else {
		// should do error handling here at some point
		tableName = "ButtonsTable";
	}
	var params = {
		TableName: tableName,
	}
	async.waterfall([
		function(cb) {
			ddb.scan(params, cb);
		},
		function(data, cb) {
			// error checking if data is null
			var targets = data["Items"];
			var content = "";
			targets.forEach(function(item) {
				content += "id: " + item["number"]["S"] + "\n";
				content += "name: " + item["name"]["S"] + "\n";
				content += "\n";
			});
			var message = {
				contentType: "PlainText",
				content: content,
			};

			console.log(content);
			var response = {
				sessionAttributes,
				dialogAction: {
					type: "Close",
					fulfillmentState,
					messsage,
				}
			}
		}
	], function(err, result) {
		callback(result);
	});
}

function getDevice(sessionAttributes, fulfillmentState, group, target, callback) {
	var tableName;
	if (group == "devices") {
		tableName = "DevicesTable";
	} else {
		// should do error handling here at some point
		tableName = "ButtonsTable";
	}
	var params = {
		TableName: tableName,
		Key: {
			"number" : {S: target},
		},
	};
	async.waterfall([
		function(cb) {
			ddb.getItem(params, cb);
		},
		function(data, cb) {
			// error checking if data is null
			var target = data["Item"];
			var content = "";
			content += "brightness: " + target["bri"]["N"] + "\n";
			content += "hue: " + target["hue"]["N"] + "\n";
			content += "saturation: " + target["sat"]["N"] + "\n";
			content += "effect: " + target["effect"]["S"] + "\n";
			content += "color type: " + target["ct"]["N"] + "\n";
			content += "colormode: " + target["colormode"]["S"] + "\n";
			var message = {
				contentType: "PlainText",
				content,
			};

			var response = {
				sessionAttributes,
				dialogAction: {
					type: "Close",
					fulfillmentState,
					messsage,
				}
			}
		}
	], function(err, result) {
		callback(result);
	});
}


// --------------- Events -----------------------
 
function dispatch(intentRequest, callback) {
    console.log(`request received for userId=${intentRequest.userId}, intentName=${intentRequest.currentIntent.name}`);
    const sessionAttributes = intentRequest.sessionAttributes;
    const slots = intentRequest.currentIntent.slots;
    const devices = slots.devices;
    const device = slots.device;
    const inputTranscript = intentRequest.inputTranscript;
    if (!device) {
    	getAll(sessionAttributes, "Fulfilled", devices, callback);
    } else {
    	// probably should error handle here too
    	getDevice(sessionAttributes, "Fulfilled", devices, device, callback);
    }    
}

// --------------- Main handler -----------------------
 
// Route the incoming request based on intent.
// The JSON body of the request is provided in the event slot.
exports.handler = (event, context, callback) => {
    try {
        dispatch(event,
            (response) => {
                callback(null, response);
            });
    } catch (err) {
        callback(err);
    }
};